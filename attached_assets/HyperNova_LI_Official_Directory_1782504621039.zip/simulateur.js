// Déclencher l'alarme
document.getElementById("triggerAlarm").addEventListener("click", function () {
    const status = document.getElementById("status");
    status.textContent = "État du système : Alarme déclenchée !";
    alert("⚠️ Alarme incendie activée !");
});

// Activer le compartimentage
document.getElementById("compartmentalize").addEventListener("click", function () {
    const status = document.getElementById("status");
    status.textContent = "État du système : Compartimentage activé !";
    alert("🚪 Compartimentage activé !");
});

// Activer le désenfumage
document.getElementById("smokeControl").addEventListener("click", function () {
    const status = document.getElementById("status");
    status.textContent = "État du système : Désenfumage activé !";
    alert("💨 Désenfumage activé !");
});

// Réarmer le système
document.getElementById("resetSystem").addEventListener("click", function () {
    const status = document.getElementById("status");
    status.textContent = "État du système : Normal";
    alert("🔄 Système réarmé !");
});
// Fonction de géolocalisation par adresse IP
async function checkAccessByIP() {
    try {
        const response = await fetch("https://ipapi.co/json/");
        const data = await response.json();

        if (data.country_code === "FR") {
            document.getElementById("status").textContent = `Bienvenue ! Vous êtes localisé à : ${data.city}, ${data.region}, France.`;
        } else {
            // Bloquer l'accès si l'utilisateur n'est pas en France
            document.body.innerHTML = `
                <h1>Accès refusé</h1>
                <p>Ce service est uniquement disponible pour les résidents de France.</p>
            `;
        }
    } catch (error) {
        document.getElementById("status").textContent = "Impossible de déterminer l'emplacement. Veuillez réessayer.";
    }
}

// Appeler la fonction de géolocalisation dès le chargement de la page
checkAccessByIP();

// Ajout des fonctionnalités interactives (Alarme, Compartimentage, Désenfumage, etc.)
document.getElementById("triggerAlarm").addEventListener("click", function () {
    const status = document.getElementById("status");
    status.textContent = "État du système : Alarme déclenchée !";
    alert("⚠️ Alarme incendie activée !");
});

document.getElementById("compartmentalize").addEventListener("click", function () {
    const status = document.getElementById("status");
    status.textContent = "État du système : Compartimentage activé !";
    alert("🚪 Compartimentage activé !");
});

document.getElementById("smokeControl").addEventListener("click", function () {
    const status = document.getElementById("status");
    status.textContent = "État du système : Désenfumage activé !";
    alert("💨 Désenfumage activé !");
});

document.getElementById("resetSystem").addEventListener("click", function () {
    const status = document.getElementById("status");
    status.textContent = "État du système : Normal";
    alert("🔄 Système réarmé !");
});
document.getElementById("triggerAlarm").addEventListener("click", function () {
    const alarmSound = document.getElementById("alarmSound");
    // Vérifiez si l'audio est chargé
    if (alarmSound) {
        alarmSound.play(); // Joue le son
    } else {
        alert("Le fichier audio ne peut pas être joué !");
    }
    const status = document.getElementById("status");
    status.textContent = "État du système : Alarme déclenchée !";
    alert("⚠️ Alarme incendie activée !");
});
