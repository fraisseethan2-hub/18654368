document.getElementById("openUsb").addEventListener("click", async () => {
    const fileList = document.getElementById("fileList");
    const preview = document.getElementById("preview");
    fileList.innerHTML = "";
    preview.innerHTML = "";
  
    try {
      const dirHandle = await window.showDirectoryPicker();
      
      for await (const entry of dirHandle.values()) {
        if (entry.kind === "file") {
          const li = document.createElement("li");
          li.textContent = entry.name;
          li.addEventListener("click", async () => {
            const file = await entry.getFile();
            previewFile(file);
          });
          fileList.appendChild(li);
        }
      }
    } catch (err) {
      alert("Accès refusé ou erreur : " + err.message);
    }
  });
  
  function previewFile(file) {
    const preview = document.getElementById("preview");
    preview.innerHTML = `<h3>📄 ${file.name}</h3>`;
    const reader = new FileReader();
  
    if (file.type.startsWith("image/")) {
      reader.onload = () => {
        preview.innerHTML += `<img src="${reader.result}" alt="${file.name}">`;
      };
      reader.readAsDataURL(file);
    } else if (file.type === "application/pdf") {
      reader.onload = () => {
        const blob = new Blob([reader.result], { type: "application/pdf" });
        const url = URL.createObjectURL(blob);
        preview.innerHTML += `<iframe src="${url}"></iframe>`;
      };
      reader.readAsArrayBuffer(file);
    } else if (file.type.startsWith("text/") || file.name.endsWith(".txt")) {
      reader.onload = () => {
        preview.innerHTML += `<pre>${reader.result}</pre>`;
      };
      reader.readAsText(file);
    } else {
      preview.innerHTML += `<p>Prévisualisation non disponible pour ce type de fichier.</p>`;
    }
  }
  