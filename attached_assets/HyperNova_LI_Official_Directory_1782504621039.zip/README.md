# Fichier neutralisé

Ce README a été neutralisé suite à la demande de suppression du générateur de vidéo Google VEO.
