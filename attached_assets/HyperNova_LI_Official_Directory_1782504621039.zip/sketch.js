function setup() {
  createCanvas(windowWidth, windowHeight);
let commencer; // nom de mon bouton
}

function draw() {
  background('#DF207A');
textSize(60);
text("mon site",400,mouseY)
}
// Géo-localisation
const locationDisplay = document.getElementById("location");

if ("geolocation" in navigator) {
    navigator.geolocation.getCurrentPosition(
        (position) => {
            const lat = position.coords.latitude.toFixed(4);
            const lon = position.coords.longitude.toFixed(4);
            locationDisplay.textContent = `📍 Localisation estimée : ${lat}°, ${lon}°`;
        },
        (error) => {
            locationDisplay.textContent = "❌ Impossible d’obtenir la localisation.";
            console.error("Erreur de géolocalisation :", error);
        }
    );
} else {
    locationDisplay.textContent = "⚠️ Géolocalisation non supportée par ce navigateur.";
}
