const video = document.getElementById('video');
const canvas = document.getElementById('photoCanvas');
const downloadPhoto = document.getElementById('downloadPhoto');
const recordedVideo = document.getElementById('recordedVideo');
const downloadVideo = document.getElementById('downloadVideo');

let mediaRecorder;
let recordedChunks = [];

// Obtenir la caméra + micro
navigator.mediaDevices.getUserMedia({ video: true, audio: true })
    .then(stream => {
        video.srcObject = stream;
        window.stream = stream;

        // Log pour vérifier audio
        const audioTracks = stream.getAudioTracks();
        if (audioTracks.length > 0) {
            console.log("✅ Audio activé :", audioTracks[0].label);
        } else {
            console.warn("❌ Aucun micro détecté !");
        }
    })
    .catch(err => {
        alert("Erreur d'accès à la caméra/micro : " + err.message);
    });

// Prendre une photo
function takePhoto() {
    const context = canvas.getContext('2d');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    context.drawImage(video, 0, 0, canvas.width, canvas.height);
    downloadPhoto.href = canvas.toDataURL('image/png');
}

// Commencer l'enregistrement vidéo avec audio
function startRecording() {
    recordedChunks = [];

    // 👇 Forcer un format avec son
    mediaRecorder = new MediaRecorder(window.stream, {
        mimeType: 'video/webm;codecs=vp8,opus'
    });

    mediaRecorder.ondataavailable = function (e) {
        if (e.data.size > 0) {
            recordedChunks.push(e.data);
        }
    };

    mediaRecorder.onstop = function () {
        const blob = new Blob(recordedChunks, { type: 'video/webm' });
        const url = URL.createObjectURL(blob);
        recordedVideo.src = url;
        downloadVideo.href = url;
    };

    mediaRecorder.start();
    console.log("🎥 Enregistrement démarré...");
}

// Arrêter l'enregistrement
function stopRecording() {
    if (mediaRecorder && mediaRecorder.state !== "inactive") {
        mediaRecorder.stop();
        console.log("🛑 Enregistrement arrêté.");
    }
}

// --- CAST GOOGLE CHROME ---
window['__onGCastApiAvailable'] = function(isAvailable) {
    if (isAvailable) {
        cast.framework.CastContext.getInstance().setOptions({
            receiverApplicationId: chrome.cast.media.DEFAULT_MEDIA_RECEIVER_APP_ID,
            autoJoinPolicy: chrome.cast.AutoJoinPolicy.ORIGIN_SCOPED
        });
    }
};

document.getElementById('castVideoBtn').addEventListener('click', async function() {
    const video = document.getElementById('recordedVideo');
    if (!video.src) {
        alert("Aucune vidéo à caster.");
        return;
    }
    if (window.cast && cast.framework) {
        const castSession = cast.framework.CastContext.getInstance().getCurrentSession();
        if (!castSession) {
            // Ouvre la boîte de dialogue de sélection d'appareil
            await cast.framework.CastContext.getInstance().requestSession();
        }
        const mediaInfo = new chrome.cast.media.MediaInfo(video.src, 'video/webm');
        const request = new chrome.cast.media.LoadRequest(mediaInfo);
        cast.framework.CastContext.getInstance().getCurrentSession().loadMedia(request).then(
            function() { /* succès */ },
            function(errorCode) { alert('Erreur lors du cast : ' + errorCode); }
        );
    } else {
        alert("Le cast n'est pas supporté par ce navigateur ou l'API Cast n'est pas chargée.");
    }
});
