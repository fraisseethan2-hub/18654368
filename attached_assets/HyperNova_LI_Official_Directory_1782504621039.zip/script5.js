document.getElementById("ytForm").addEventListener("submit", function (e) {
    e.preventDefault();
  
    const link = document.getElementById("ytLink").value.trim();
    const resultDiv = document.getElementById("result");
  
    if (!link.startsWith("http")) {
      resultDiv.innerHTML = "<p style='color:red'>Lien invalide</p>";
      return;
    }
  
    // Simulation ou redirection vers un convertisseur tiers (car pas de vraie API publique gratuite)
    const encodedLink = encodeURIComponent(link);
    const redirectUrl = `https://www.yt-download.org/api/button/mp4/${extractYouTubeID(link)}`;
  
    resultDiv.innerHTML = `
      <p>Votre vidéo est prête :</p>
      <iframe src="${redirectUrl}" width="100%" height="150" frameborder="0"></iframe>
    `;
  });
  
  // Utilitaire pour extraire l’ID de la vidéo depuis une URL YouTube
  function extractYouTubeID(url) {
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
    const match = url.match(regExp);
    return match && match[2].length === 11 ? match[2] : null;
  }
  