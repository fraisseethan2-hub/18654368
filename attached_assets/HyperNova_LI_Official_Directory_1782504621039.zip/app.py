from flask import Flask, render_template, request, jsonify
import requests

app = Flask(__name__)

API_KEY = "652ba182-c8eb-4692-97d7-f3ce20a3ea9d"  # Remplacez par votre clé API DeepAI

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/generate", methods=["POST"])
def generate():
    prompt = request.json.get("prompt")
    response = requests.post(
        "https://api.deepai.org/api/text2img",
        data={'text': prompt},
        headers={'Api-Key': API_KEY}
    )
    print(response.json())  # Affiche la réponse complète de l'API DeepAI
    image_url = response.json().get("output_url")
    return jsonify({"image_url": image_url})

if __name__ == "__main__":
    app.run(debug=True)
