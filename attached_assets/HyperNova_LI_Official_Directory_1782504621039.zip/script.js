let score = 0;
let timeLeft = 10;
let timer;
let gameActive = false;

const gameArea = document.getElementById("game-area");
const scoreDisplay = document.getElementById("score");
const timeDisplay = document.getElementById("time");

function startGame() {
    if (gameActive) return;
    gameActive = true;
    score = 0;
    timeLeft = 10;
    scoreDisplay.textContent = score;
    timeDisplay.textContent = timeLeft;
    spawnCircle();

    timer = setInterval(() => {
        timeLeft--;
        timeDisplay.textContent = timeLeft;
        if (timeLeft <= 0) {
            endGame();
        }
    }, 1000);
}

function spawnCircle() {
    const circle = document.createElement("div");
    circle.classList.add("circle");

    const maxX = gameArea.clientWidth - 50;
    const maxY = gameArea.clientHeight - 50;
    const x = Math.random() * maxX;
    const y = Math.random() * maxY;

    circle.style.left = `${x}px`;
    circle.style.top = `${y}px`;

    circle.onclick = () => {
        score++;
        scoreDisplay.textContent = score;
        circle.remove();
        if (gameActive) {
            spawnCircle();
        }
    };

    gameArea.appendChild(circle);
}

function endGame() {
    gameActive = false;
    clearInterval(timer);
    const circles = document.querySelectorAll(".circle");
    circles.forEach(circle => circle.remove());
    alert("Temps écoulé ! Ton score : " + score);
}
// Géo-localisation
const locationDisplay = document.getElementById("location");

if ("geolocation" in navigator) {
    navigator.geolocation.getCurrentPosition(
        (position) => {
            const lat = position.coords.latitude.toFixed(4);
            const lon = position.coords.longitude.toFixed(4);
            locationDisplay.textContent = `📍 Localisation estimée : ${lat}°, ${lon}°`;
        },
        (error) => {
            locationDisplay.textContent = "❌ Impossible d’obtenir la localisation.";
            console.error("Erreur de géolocalisation :", error);
        }
    );
} else {
    locationDisplay.textContent = "⚠️ Géolocalisation non supportée par ce navigateur.";
}
function updateLocation() {
    const locationDisplay = document.getElementById("location");
    locationDisplay.textContent = "📡 Recherche de position...";

    if ("geolocation" in navigator) {
        navigator.geolocation.getCurrentPosition(
            (position) => {
                const lat = position.coords.latitude.toFixed(4);
                const lon = position.coords.longitude.toFixed(4);
                locationDisplay.textContent = `📍 Localisation estimée : ${lat}°, ${lon}°`;
            },
            (error) => {
                locationDisplay.textContent = "❌ Impossible d’obtenir la localisation.";
                console.error("Erreur de géolocalisation :", error);
            }
        );
    } else {
        locationDisplay.textContent = "⚠️ Géolocalisation non supportée par ce navigateur.";
    }
}
function updateLocation() {
    const locationDisplay = document.getElementById("location");
    const addressDisplay = document.getElementById("address");

    locationDisplay.textContent = "📡 Recherche de position...";
    addressDisplay.textContent = "🌍 Recherche de l'adresse...";

    if ("geolocation" in navigator) {
        navigator.geolocation.getCurrentPosition(
            (position) => {
                const lat = position.coords.latitude.toFixed(4);
                const lon = position.coords.longitude.toFixed(4);
                locationDisplay.textContent = `📍 Localisation estimée : ${lat}°, ${lon}°`;

                // Appel à l'API de géocodage inverse (Nominatim)
                fetch(`https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lon}&format=json`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.address) {
                            const { city, town, village, state, country } = data.address;
                            const locationName = city || town || village || state || "Inconnu";
                            addressDisplay.textContent = `🌍 Adresse : ${locationName}, ${country}`;
                        } else {
                            addressDisplay.textContent = "🌍 Adresse : introuvable.";
                        }
                    })
                    .catch(() => {
                        addressDisplay.textContent = "❌ Erreur lors de la récupération de l'adresse.";
                    });
            },
            (error) => {
                locationDisplay.textContent = "❌ Impossible d’obtenir la localisation.";
                addressDisplay.textContent = "🌍 Adresse : inconnue.";
                console.error("Erreur de géolocalisation :", error);
            }
        );
    } else {
        locationDisplay.textContent = "⚠️ Géolocalisation non supportée.";
        addressDisplay.textContent = "🌍 Adresse : non disponible.";
    }
}

// Appel initial au chargement de la page
updateLocation();
