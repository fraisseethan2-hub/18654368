// Références DOM
const settingsBtn = document.getElementById('settingsBtn');
const settingsMenu = document.getElementById('settingsMenu');
const closeSettingsBtn = document.getElementById('closeSettingsBtn');
const backgroundColor = document.getElementById('backgroundColor');
const textColor = document.getElementById('textColor');
const fontSize = document.getElementById('fontSize');
const notepad = document.getElementById('notepad');

// Fonction pour ouvrir/fermer le menu des paramètres
settingsBtn.addEventListener('click', () => {
  settingsMenu.style.display = 'block';
});

closeSettingsBtn.addEventListener('click', () => {
  settingsMenu.style.display = 'none';
});

// Appliquer les paramètres de style à l'éditeur de texte
backgroundColor.addEventListener('input', (e) => {
  document.body.style.backgroundColor = e.target.value;
  localStorage.setItem('backgroundColor', e.target.value);
});

textColor.addEventListener('input', (e) => {
  notepad.style.color = e.target.value;
  localStorage.setItem('textColor', e.target.value);
});

fontSize.addEventListener('input', (e) => {
  notepad.style.fontSize = `${e.target.value}px`;
  localStorage.setItem('fontSize', e.target.value);
});

// Charger les paramètres précédemment enregistrés
window.onload = function() {
  const savedBackgroundColor = localStorage.getItem('backgroundColor');
  const savedTextColor = localStorage.getItem('textColor');
  const savedFontSize = localStorage.getItem('fontSize');

  if (savedBackgroundColor) {
    document.body.style.backgroundColor = savedBackgroundColor;
    backgroundColor.value = savedBackgroundColor;
  }
  if (savedTextColor) {
    notepad.style.color = savedTextColor;
    textColor.value = savedTextColor;
  }
  if (savedFontSize) {
    notepad.style.fontSize = `${savedFontSize}px`;
    fontSize.value = savedFontSize;
  }
};
// Fonction de téléchargement du fichier en format .txt
downloadBtn.addEventListener('click', () => {
    const text = notepad.value; // Récupère le contenu du notepad
  
    // Crée un Blob avec le texte
    const blob = new Blob([text], { type: 'text/plain' });
    
    // Crée un objet URL pour le Blob
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'notepad.txt'; // Nom du fichier à télécharger
  
    // Simule un clic pour télécharger
    link.click();
  });
// Fonction pour obtenir la localisation
document.getElementById('getLocationBtn').addEventListener('click', () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const latitude = position.coords.latitude;
          const longitude = position.coords.longitude;
          const coords = `Latitude: ${latitude}, Longitude: ${longitude}`;
  
          // Afficher les coordonnées dans le <p id="location">
          document.getElementById('location').innerHTML = coords;
  
          // Utilisation de l'API de géocodage pour obtenir l'adresse à partir des coordonnées
          const apiKey = 'YOUR_GOOGLE_MAPS_API_KEY'; // Remplacez par votre clé API Google Maps
          const geocodeUrl = `https://maps.googleapis.com/maps/api/geocode/json?latlng=${latitude},${longitude}&key=${apiKey}`;
  
          // Requête vers l'API de Google Maps
          fetch(geocodeUrl)
            .then(response => response.json())
            .then(data => {
              if (data.status === 'OK') {
                const results = data.results[0];
                const city = results.address_components.find(component => component.types.includes('locality')).long_name;
                const country = results.address_components.find(component => component.types.includes('country')).long_name;
                const address = `${city}, ${country}`;
                document.getElementById('location').innerHTML += `<br>Adresse: ${address}`;
              } else {
                document.getElementById('location').innerHTML += `<br>Impossible de récupérer l'adresse`;
              }
            })
            .catch(error => {
              console.error('Erreur lors de la récupération de l’adresse:', error);
              document.getElementById('location').innerHTML += `<br>Erreur lors de la récupération de l’adresse`;
            });
        },
        (error) => {
          console.error('Erreur de géolocalisation:', error);
          document.getElementById('location').innerHTML = 'Impossible d\'obtenir la localisation';
        }
      );
    } else {
      alert('La géolocalisation n\'est pas supportée par ce navigateur.');
    }
  });
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const latitude = position.coords.latitude;
        const longitude = position.coords.longitude;
  
        // Afficher la latitude et la longitude
        document.getElementById('location').innerHTML = `Latitude: ${latitude}, Longitude: ${longitude}`;
  
        // Requête à l'API de Nominatim pour récupérer l'adresse
        const geocodeUrl = `https://nominatim.openstreetmap.org/reverse?lat=${latitude}&lon=${longitude}&format=json&addressdetails=1`;
  
        fetch(geocodeUrl)
          .then(response => response.json())
          .then(data => {
            if (data && data.address) {
              // Extraire la ville et le pays
              const city = data.address.city || data.address.town || data.address.village;
              const country = data.address.country;
              const address = `${city}, ${country}`;
              document.getElementById('location').innerHTML += `<br>Adresse: ${address}`;
            } else {
              document.getElementById('location').innerHTML += `<br>Adresse non disponible.`;
            }
          })
          .catch(error => {
            console.error('Erreur lors de la récupération de l’adresse:', error);
            document.getElementById('location').innerHTML += `<br>Erreur lors de la récupération de l’adresse`;
          });
      },
      (error) => {
        console.error('Erreur de géolocalisation:', error);
        document.getElementById('location').innerHTML = 'Impossible d\'obtenir la localisation. Assurez-vous que vous avez autorisé la géolocalisation.';
      }
    );
  } else {
    alert('La géolocalisation n\'est pas supportée par ce navigateur.');
  }
  document.getElementById('printBtn').addEventListener('click', () => {
    window.print();
  });
  window.addEventListener('beforeunload', (event) => {
    event.preventDefault(); // Nécessaire pour certains navigateurs
    event.returnValue = ''; // Affiche la boîte de dialogue du navigateur
  });
  document.getElementById('shareTextBtn').addEventListener('click', async () => {
    const textContent = document.getElementById('notepad').value;
  
    if (!textContent.trim()) {
      alert("Le notepad est vide, rien à partager !");
      return;
    }
  
    if (navigator.share) {
      try {
        await navigator.share({
          title: "Mon texte",
          text: textContent
        });
        alert("Texte partagé avec succès !");
      } catch (error) {
        console.error("Erreur lors du partage :", error);
      }
    } else {
      alert("Le partage n'est pas pris en charge par votre navigateur.");
    }
  });
      