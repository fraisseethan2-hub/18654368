// Fichier neutralisé par demande utilisateur.
// Le script original a été supprimé.
