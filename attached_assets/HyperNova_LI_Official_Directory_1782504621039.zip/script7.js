// 🔊 Alarme sonore
const alarmSound = new Audio("alarm.mp3");

// 🕒 Onglets
function openTab(event, tabName) {
  let i, tabContent, tabButtons;

  // Masquer tous les contenus des onglets
  tabContent = document.getElementsByClassName("tab-content");
  for (i = 0; i < tabContent.length; i++) {
    tabContent[i].classList.remove("active");
  }

  // Supprimer la classe "active" de tous les boutons d'onglets
  tabButtons = document.getElementsByClassName("tab-button");
  for (i = 0; i < tabButtons.length; i++) {
    tabButtons[i].classList.remove("active");
  }

  // Afficher l'onglet actuel et ajouter la classe "active" au bouton de l'onglet
  document.getElementById(tabName).classList.add("active");
  event.currentTarget.classList.add("active");
}

// 🕰️ Horloge
function updateClock() {
  const now = new Date();
  document.getElementById("localTime").textContent = `Locale : ${now.toLocaleTimeString()}`;

  const timezones = ["UTC", "Europe/Paris", "America/New_York", "Asia/Tokyo"];
  let html = "";
  timezones.forEach(tz => {
    const time = now.toLocaleTimeString("fr-FR", { timeZone: tz });
    html += `<p>${tz} : ${time}</p>`;
  });
  document.getElementById("worldClocks").innerHTML = html;
}

// 📍 Géo-localisation & Horloge locale
function updateGeoClock(position) {
  const lat = position.coords.latitude;
  const lon = position.coords.longitude;

  // Calculer le fuseau horaire à partir de la position (utilisation de la méthode Intl.DateTimeFormat)
  const date = new Date();
  const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;

  // Définir l'heure en fonction du fuseau horaire
  const geoTime = new Date(date.toLocaleString('en-US', { timeZone: timeZone }));
  
  document.getElementById("geoClock").innerHTML = `<p>Heure locale de votre emplacement : ${geoTime.toLocaleTimeString()}</p>`;
}

// 🚨 Si la géolocalisation est disponible
if (navigator.geolocation) {
  navigator.geolocation.getCurrentPosition(updateGeoClock, () => {
    document.getElementById("geoClock").textContent = "Erreur de géolocalisation.";
  });
} else {
  document.getElementById("geoClock").textContent = "Géolocalisation non supportée par ce navigateur.";
}

setInterval(updateClock, 1000);
updateClock();

// ⏱️ Chronomètre
let swInterval, swStart = 0;
document.getElementById("startStopwatch").addEventListener("click", () => {
  if (swInterval) {
    clearInterval(swInterval);
    swInterval = null;
  } else {
    const startTime = Date.now() - swStart;
    swInterval = setInterval(() => {
      swStart = Date.now() - startTime;
      const time = new Date(swStart).toISOString().substr(11, 8);
      document.getElementById("stopwatchDisplay").textContent = time;
    }, 100);
  }
});

document.getElementById("resetStopwatch").addEventListener("click", () => {
  clearInterval(swInterval);
  swInterval = null;
  swStart = 0;
  document.getElementById("stopwatchDisplay").textContent = "00:00:00";
  document.getElementById("lapTimes").innerHTML = "";
});

document.getElementById("lapBtn").addEventListener("click", () => {
  const time = document.getElementById("stopwatchDisplay").textContent;
  const li = document.createElement("li");
  li.textContent = `Tour : ${time}`;
  document.getElementById("lapTimes").appendChild(li);
});

// ⏳ Minuteur
let timerInterval;
document.getElementById("startTimer").addEventListener("click", () => {
  const minutes = parseInt(document.getElementById("timerMinutes").value);
  if (isNaN(minutes)) return;

  let seconds = minutes * 60;
  updateTimerDisplay(seconds);

  clearInterval(timerInterval);
  timerInterval = setInterval(() => {
    seconds--;
    updateTimerDisplay(seconds);
    if (seconds <= 0) {
      clearInterval(timerInterval);
      alarmSound.play();
      alert("⏰ Temps écoulé !");
    }
  }, 1000);
});

function updateTimerDisplay(s) {
  const min = String(Math.floor(s / 60)).padStart(2, '0');
  const sec = String(s % 60).padStart(2, '0');
  document.getElementById("timerDisplay").textContent = `${min}:${sec}`;
}

// 🔔 Alarmes
let alarms = [];

function saveAlarms() {
  localStorage.setItem("alarms", JSON.stringify(alarms));
}

function loadAlarms() {
  const saved = localStorage.getItem("alarms");
  if (saved) {
    alarms = JSON.parse(saved);
    renderAlarms();
  }
}

document.getElementById("setAlarm").addEventListener("click", () => {
  const time = document.getElementById("alarmTime").value;
  if (!time) return;
  if (!alarms.includes(time)) {
    alarms.push(time);
    saveAlarms();
    renderAlarms();
  }
});

function renderAlarms() {
  const ul = document.getElementById("alarmList");
  ul.innerHTML = "";
  alarms.forEach((alarm) => {
    const li = document.createElement("li");
    li.textContent = `🔔 ${alarm}`;
    ul.appendChild(li);
  });
}

setInterval(() => {
  const now = new Date();
  const currentTime = now.toTimeString().slice(0, 5); // "HH:MM"

  if (alarms.includes(currentTime)) {
    alarmSound.play();
    alert(`🔔 Alarme : ${currentTime}`);
    alarms = alarms.filter(a => a !== currentTime);
    renderAlarms();
    saveAlarms();
  }
}, 1000);
