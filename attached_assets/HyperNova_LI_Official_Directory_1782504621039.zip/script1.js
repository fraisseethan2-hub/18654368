function appendValue(val) {
    document.getElementById("display").value += val;
  }
  
  function clearDisplay() {
    document.getElementById("display").value = "";
  }
  
  function calculate() {
    let expression = document.getElementById("display").value;
  
    // Remplacer log et ln par les fonctions Math correspondantes
    expression = expression.replace(/log\(/g, 'Math.log10(');
    expression = expression.replace(/ln\(/g, 'Math.log(');
  
    try {
      let result = eval(expression);
      document.getElementById("display").value = result;
    } catch (e) {
      document.getElementById("display").value = "Erreur";
    }
  }
  document.getElementById("accentColor").addEventListener("input", (e) => {
    const accent = e.target.value;
    document.documentElement.style.setProperty('--accent-color', accent);
    document.documentElement.style.setProperty('--accent-color-hover', darkenColor(accent, 20));
  });
  
  // Fonction pour assombrir une couleur hex (utilisée pour le hover)
  function darkenColor(hex, percent) {
    const num = parseInt(hex.slice(1), 16);
    let r = (num >> 16) - percent;
    let g = ((num >> 8) & 0x00FF) - percent;
    let b = (num & 0x0000FF) - percent;
    r = Math.max(r, 0);
    g = Math.max(g, 0);
    b = Math.max(b, 0);
    return `rgb(${r}, ${g}, ${b})`;
  }
  let notificationsEnabled = false; // Etat initial des notifications

  // Sélectionner le slider
  const notificationToggle = document.getElementById("notificationToggle");
  
  // Vérifier l'état du slider à chaque changement
  notificationToggle.addEventListener("change", () => {
    if (notificationToggle.checked) {
      // Demander la permission pour envoyer des notifications
      Notification.requestPermission().then(permission => {
        if (permission === "granted") {
          notificationsEnabled = true;
        } else {
          alert("Les notifications ont été refusées. Vous pouvez les activer dans les paramètres de votre navigateur.");
          notificationToggle.checked = false; // Réinitialise le slider si la permission est refusée
        }
      });
    } else {
      notificationsEnabled = false;
    }
  });
  
  // Fonction pour afficher une notification
  function showNotification(message) {
    if (notificationsEnabled && Notification.permission === "granted") {
      new Notification("Résultat du calcul", {
        body: message,
        icon: 'https://img.icons8.com/ios/452/calculator.png' // Icône pour la notification
      });
    }
  }
  
  // Code pour effectuer le calcul (exemple)
  document.querySelector(".equal").addEventListener("click", () => {
    const result = document.querySelector(".display").value;  // Supposons que ce soit le résultat affiché
    if (notificationsEnabled) {
      showNotification(`Le résultat est : ${result}`);
    }
  });
  const pipBtn = document.getElementById("pipToggle");
  const calculator = document.querySelector(".calculator");
  
  let pipMode = false;
  
  pipBtn.addEventListener("click", () => {
    pipMode = !pipMode;
    calculator.classList.toggle("pip-mode", pipMode);
    pipBtn.textContent = pipMode ? "Restaurer" : "Réduire";
  });
// Drag & drop de la calculatrice en mode PiP
const dragBar = document.querySelector(".drag-bar");

let isDragging = false;
let offsetX = 0;
let offsetY = 0;

dragBar.addEventListener("mousedown", (e) => {
  if (!calculator.classList.contains("pip-mode")) return;

  isDragging = true;
  const rect = calculator.getBoundingClientRect();
  offsetX = e.clientX - rect.left;
  offsetY = e.clientY - rect.top;

  calculator.style.transition = "none";
});

document.addEventListener("mousemove", (e) => {
  if (!isDragging) return;

  const x = e.clientX - offsetX;
  const y = e.clientY - offsetY;

  calculator.style.left = `${x}px`;
  calculator.style.top = `${y}px`;
  calculator.style.right = "auto";
  calculator.style.bottom = "auto";
  calculator.style.position = "fixed";
});

document.addEventListener("mouseup", () => {
  isDragging = false;
  calculator.style.transition = ""; // Remet la transition si besoin
});
      