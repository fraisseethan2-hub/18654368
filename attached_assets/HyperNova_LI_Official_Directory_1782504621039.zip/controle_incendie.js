// Gestion du bouton d'alarme
document.getElementById("triggerAlarm").addEventListener("click", function () {
    const alarmStatus = document.getElementById("alarmStatus");
    alarmStatus.textContent = "État de l'alarme : Active !";
    alert("⚠️ Alarme incendie déclenchée !");
});

// Gestion des portes coupe-feu
document.getElementById("closeDoors").addEventListener("click", function () {
    const doorStatus = document.getElementById("doorStatus");
    doorStatus.textContent = "État des portes : Fermées";
    alert("🚪 Les portes coupe-feu sont fermées !");
});

// Émetteur de son
document.getElementById("soundEmitter").addEventListener("click", function () {
    const soundStatus = document.getElementById("soundStatus");
    soundStatus.textContent = "État du son : Actif";
    alert("🔊 L'émetteur de son est activé !");
});

// Fonction de géolocalisation par adresse IP
async function getGeolocation() {
    const locationElement = document.getElementById("location");
    try {
        const response = await fetch("https://ipapi.co/json/");
        const data = await response.json();
        if (data.country_code === "FR") {
            locationElement.textContent = `Vous êtes localisé à : ${data.city}, ${data.region}, France.`;
        } else {
            locationElement.textContent = "⚠️ Ce service est disponible uniquement pour les résidents de France.";
        }
    } catch (error) {
        locationElement.textContent = "Impossible de déterminer l'emplacement.";
    }
}

getGeolocation();
// Fonction de géolocalisation par adresse IP avec blocage pour les non-résidents
async function getGeolocation() {
    const locationElement = document.getElementById("location");
    try {
        const response = await fetch("https://ipapi.co/json/");
        const data = await response.json();

        if (data.country_code === "FR") {
            locationElement.textContent = `Vous êtes localisé à : ${data.city}, ${data.region}, France. Bienvenue !`;
        } else {
            // Bloquer l'accès si l'utilisateur n'est pas en France
            document.body.innerHTML = `
                <h1>Accès refusé</h1>
                <p>Ce service est uniquement disponible pour les résidents de France.</p>
            `;
        }
    } catch (error) {
        locationElement.textContent = "Impossible de déterminer l'emplacement. Veuillez réessayer.";
    }
}

getGeolocation();

// Gestion du bouton d'alarme
document.getElementById("triggerAlarm")?.addEventListener("click", function () {
    const alarmStatus = document.getElementById("alarmStatus");
    alarmStatus.textContent = "État de l'alarme : Active !";
    alert("⚠️ Alarme incendie déclenchée !");
});

// Gestion des portes coupe-feu
document.getElementById("closeDoors")?.addEventListener("click", function () {
    const doorStatus = document.getElementById("doorStatus");
    doorStatus.textContent = "État des portes : Fermées";
    alert("🚪 Les portes coupe-feu sont fermées !");
});

// Émetteur de son
document.getElementById("soundEmitter")?.addEventListener("click", function () {
    const soundStatus = document.getElementById("soundStatus");
    soundStatus.textContent = "État du son : Actif";
    alert("🔊 L'émetteur de son est activé !");
});
// Gérer l'alarme incendie
document.getElementById("triggerAlarm").addEventListener("click", function () {
    const status = document.getElementById("status");
    status.textContent = "Alarme incendie activée !";
    alert("⚠️ Alarme incendie déclenchée !");
});

// Gérer l'émission de son
document.getElementById("soundButton").addEventListener("click", function () {
    const status = document.getElementById("status");
    status.textContent = "Émetteur de son activé !";
    alert("🔊 Le son est diffusé !");
});

// Gérer les portes coupe-feu
document.getElementById("closeDoors").addEventListener("click", function () {
    const status = document.getElementById("status");
    status.textContent = "Portes coupe-feu fermées !";
    alert("🚪 Portes fermées !");
});
// Jouer le son de l'alarme
document.getElementById("triggerAlarm").addEventListener("click", function () {
    const alarmSound = document.getElementById("alarmSound");
    alarmSound.play();
    const status = document.getElementById("status");
    status.textContent = "Alarme incendie activée !";
    alert("⚠️ Alarme incendie déclenchée !");
});

// Jouer le son de l'émetteur
document.getElementById("soundButton").addEventListener("click", function () {
    const soundEmitterAudio = document.getElementById("soundEmitterAudio");
    soundEmitterAudio.play();
    const status = document.getElementById("status");
    status.textContent = "Émetteur de son activé !";
    alert("🔊 Le son est diffusé !");
});
