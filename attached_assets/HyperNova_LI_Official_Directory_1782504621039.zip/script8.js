let isRecording = false;
let audioBlob;
let audioURL;
let mediaRecorder;
let audioElement = document.getElementById("audio");
let statusDiv = document.getElementById("status");

const recordBtn = document.getElementById("recordBtn");
const stopBtn = document.getElementById("stopBtn");
const playBtn = document.getElementById("playBtn");
const downloadBtn = document.getElementById("downloadBtn");

const locationInfo = document.getElementById("locationInfo");
const addressInfo = document.getElementById("addressInfo");

async function startRecording() {
    try {
        // Demander l'accès au microphone
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });

        // Créer un MediaRecorder pour l'enregistrement
        mediaRecorder = new MediaRecorder(stream);
        mediaRecorder.ondataavailable = event => {
            audioBlob = event.data;
            audioURL = URL.createObjectURL(audioBlob);
            audioElement.src = audioURL;
            playBtn.disabled = false;
            downloadBtn.disabled = false;
            statusDiv.textContent = "Enregistrement terminé !";
        };

        mediaRecorder.start();
        isRecording = true;
        recordBtn.textContent = "Pause";
        stopBtn.disabled = false;
        statusDiv.textContent = "Enregistrement en cours...";
    } catch (error) {
        console.error("Erreur lors de l'accès au microphone:", error);
        statusDiv.textContent = "Impossible d'accéder au microphone.";
    }
}

function stopRecording() {
    mediaRecorder.stop();
    isRecording = false;
    recordBtn.textContent = "Reprendre";
    stopBtn.disabled = true;
}

function playAudio() {
    audioElement.play();
}

function downloadAudio() {
    const link = document.createElement("a");
    link.href = audioURL;
    link.download = "enregistrement.wav";
    link.click();
}

// Fonction pour récupérer la géolocalisation
function updateLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition, showError);
    } else {
        locationInfo.textContent = "La géolocalisation n'est pas supportée par ce navigateur.";
    }
}

function showPosition(position) {
    let latitude = position.coords.latitude;
    let longitude = position.coords.longitude;

    locationInfo.textContent = `Latitude: ${latitude}, Longitude: ${longitude}`;

    // Appeler l'API pour récupérer l'adresse
    fetch(`https://nominatim.openstreetmap.org/reverse?lat=${latitude}&lon=${longitude}&format=json`)
        .then(response => response.json())
        .then(data => {
            let address = data.address;
            let city = address.city || address.town || address.village || 'Ville inconnue';
            let country = address.country || 'Pays inconnu';
            addressInfo.textContent = `Adresse: ${city}, ${country}`;
        })
        .catch(error => {
            addressInfo.textContent = "Impossible de récupérer l'adresse.";
            console.error("Erreur de géolocalisation :", error);
        });
}

function showError(error) {
    switch (error.code) {
        case error.PERMISSION_DENIED:
            locationInfo.textContent = "L'utilisateur a refusé la demande de géolocalisation.";
            break;
        case error.POSITION_UNAVAILABLE:
            locationInfo.textContent = "Les informations de localisation sont indisponibles.";
            break;
        case error.TIMEOUT:
            locationInfo.textContent = "La demande de géolocalisation a expiré.";
            break;
        default:
            locationInfo.textContent = "Une erreur inconnue est survenue.";
            break;
    }
}

// Fonction qui gère l'enregistrement/arrêt de l'enregistrement
function toggleRecording() {
    if (isRecording) {
        stopRecording();
    } else {
        startRecording();
    }
}
async function checkAccess() {
    let isAllowed = false;

    // Vérification via l'API IP
    try {
        let ipResponse = await fetch("http://ip-api.com/json/");
        let ipData = await ipResponse.json();

        if (ipData.countryCode === "FR") {
            isAllowed = true;
        }
    } catch (error) {
        console.error("Erreur avec la vérification IP :", error);
    }

    // Vérification via la géolocalisation GPS
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(async position => {
            let latitude = position.coords.latitude;
            let longitude = position.coords.longitude;

            try {
                let geoResponse = await fetch(`https://nominatim.openstreetmap.org/reverse?lat=${latitude}&lon=${longitude}&format=json`);
                let geoData = await geoResponse.json();

                let country = geoData.address.country || "Pays inconnu";

                if (country === "France") {
                    isAllowed = true;
                }
            } catch (error) {
                console.error("Erreur lors de la vérification de la localisation :", error);
            }

            applyRestriction(isAllowed);
        }, showError);
    } else {
        applyRestriction(isAllowed);
    }
}

function applyRestriction(isAllowed) {
    if (!isAllowed) {
        document.body.innerHTML = "<h1>Accès restreint : Ce site est uniquement disponible en France.</h1>";
    }
}

// Appeler la fonction au chargement du site
checkAccess();
document.getElementById("castNativeBtn").addEventListener("click", () => {
    let audioElement = document.getElementById("audio"); // Assure-toi que ton élément audio est bien défini
    let mediaStream = audioElement.captureStream();

    navigator.mediaDevices.getDisplayMedia({
        video: false,
        audio: true
    }).then(stream => {
        let videoElement = document.createElement("video");
        videoElement.srcObject = stream;
        videoElement.play();
        console.log("Cast lancé !");
    }).catch(error => {
        console.error("Erreur de cast :", error);
    });
});
