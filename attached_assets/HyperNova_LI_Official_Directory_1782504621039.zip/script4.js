document.getElementById('pdfForm').onsubmit = async function(e) {
  e.preventDefault();

  // Collecter les informations du formulaire
  const fileInput = document.getElementById('pdfFile');
  const password = document.getElementById('password').value;
  const permissions = [];
  const permissionCheckboxes = document.querySelectorAll('input[name="permissions[]"]:checked');

  permissionCheckboxes.forEach(checkbox => {
      permissions.push(checkbox.value);
  });

  // Assurez-vous qu'un fichier a été téléchargé
  if (fileInput.files.length === 0) {
      document.getElementById('statusMessage').innerText = 'Veuillez télécharger un fichier PDF.';
      return;
  }

  const file = fileInput.files[0];
  const formData = new FormData();
  formData.append('file', file);
  formData.append('password', password);
  formData.append('permissions', JSON.stringify(permissions));

  try {
      // Utiliser une API tierce (par exemple, PDF.co) pour sécuriser le PDF
      const response = await fetch('https://api.pdf.co/v1/pdf/edit/add-password', {
          method: 'POST',
          headers: {
              'x-api-key': 'fraisseethan2@gmail.com_PPZeMDyrVRzDv2ktN0sp4l00mByVdsADBsWIgGyLanPJ4X6nP72dMxshLIBLD5NK' // Remplacer par ta propre clé API
          },
          body: formData
      });

      const data = await response.json();
      if (data.error) {
          document.getElementById('statusMessage').innerText = 'Erreur: ' + data.message;
      } else {
          // Afficher le lien pour télécharger le fichier PDF protégé
          const downloadLink = data.url;
          document.getElementById('statusMessage').innerHTML = `PDF protégé avec succès. <a href="${downloadLink}" target="_blank">Téléchargez le PDF protégé</a>`;
      }
  } catch (error) {
      document.getElementById('statusMessage').innerText = 'Une erreur s\'est produite. Veuillez réessayer plus tard.';
      console.error(error);
  }
}
